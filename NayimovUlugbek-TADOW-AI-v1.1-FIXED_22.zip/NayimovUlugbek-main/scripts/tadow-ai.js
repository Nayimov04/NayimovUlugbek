(() => {
  "use strict";
  const copy = {
    en: { open: "Open TADOW AI", close: "Close chat", subtitle: "DIGITAL REPRESENTATIVE", welcome: "Hello. I'm TADOW AI, the digital representative of Nayimov Ulugbek. I can help you explore his background, projects and professional interests. What would you like to know?", placeholder: "Ask about Ulugbek or his work…", send: "Send message", note: "AI-generated responses. Please verify important information.", quick: ["Who is Ulugbek?", "Explore his projects", "How can I contact him?"], error: "I couldn't connect just now. Please try again." },
    ko: { open: "TADOW AI 열기", close: "채팅 닫기", subtitle: "디지털 공식 어시스턴트", welcome: "안녕하세요. 저는 Nayimov Ulugbek의 디지털 대표 TADOW AI입니다. 그의 배경, 프로젝트 및 전문 관심 분야를 안내해 드립니다. 무엇이 궁금하신가요?", placeholder: "Ulugbek 또는 그의 프로젝트에 대해 질문하세요…", send: "메시지 보내기", note: "AI가 생성한 답변입니다. 중요한 정보는 확인해 주세요.", quick: ["Ulugbek은 누구인가요?", "프로젝트 보기", "어떻게 연락하나요?"], error: "지금 연결할 수 없습니다. 다시 시도해 주세요." },
    uz: { open: "TADOW AI'ni ochish", close: "Chatni yopish", subtitle: "RAQAMLI VAKIL", welcome: "Assalomu alaykum. Men Nayimov Ulugbekning raqamli vakili — TADOW AI. Uning faoliyati, loyihalari va professional qiziqishlari haqida ma'lumot beraman. Nima bilmoqchisiz?", placeholder: "Ulugbek yoki uning loyihalari haqida so'rang…", send: "Xabar yuborish", note: "Javoblar AI tomonidan yaratiladi. Muhim ma'lumotlarni tekshiring.", quick: ["Ulugbek kim?", "Loyihalarini ko'rish", "Qanday bog'lanish mumkin?"], error: "Hozir ulanib bo'lmadi. Qayta urinib ko'ring." },
    ru: { open: "Открыть TADOW AI", close: "Закрыть чат", subtitle: "ЦИФРОВОЙ ПРЕДСТАВИТЕЛЬ", welcome: "Здравствуйте. Я TADOW AI, цифровой представитель Nayimov Ulugbek. Я помогу узнать о его опыте, проектах и профессиональных интересах. Что вас интересует?", placeholder: "Спросите об Ulugbek или его проектах…", send: "Отправить", note: "Ответы созданы ИИ. Проверяйте важную информацию.", quick: ["Кто такой Ulugbek?", "Его проекты", "Как связаться?"], error: "Не удалось подключиться. Попробуйте ещё раз." },
    es: { open: "Abrir TADOW AI", close: "Cerrar chat", subtitle: "REPRESENTANTE DIGITAL", welcome: "Hola. Soy TADOW AI, el representante digital de Nayimov Ulugbek. Puedo ayudarte a conocer su trayectoria, proyectos e intereses profesionales. ¿Qué te gustaría saber?", placeholder: "Pregunta sobre Ulugbek o sus proyectos…", send: "Enviar mensaje", note: "Respuestas generadas por IA. Verifica la información importante.", quick: ["¿Quién es Ulugbek?", "Ver sus proyectos", "¿Cómo contactarlo?"], error: "No se pudo conectar. Inténtalo de nuevo." },
    de: { open: "TADOW AI öffnen", close: "Chat schließen", subtitle: "DIGITALER REPRÄSENTANT", welcome: "Hallo. Ich bin TADOW AI, der digitale Repräsentant von Nayimov Ulugbek. Ich helfe Ihnen, mehr über seinen Hintergrund, seine Projekte und beruflichen Interessen zu erfahren. Was möchten Sie wissen?", placeholder: "Fragen Sie nach Ulugbek oder seinen Projekten…", send: "Nachricht senden", note: "KI-generierte Antworten. Bitte wichtige Informationen überprüfen.", quick: ["Wer ist Ulugbek?", "Seine Projekte ansehen", "Wie kann ich ihn kontaktieren?"], error: "Verbindung fehlgeschlagen. Bitte versuchen Sie es erneut." }
  };

  const root = document.createElement("div");
  root.id = "tadow-ai-root";
  root.innerHTML = `
    <button class="tadow-launcher" type="button" aria-label="Open TADOW AI" aria-expanded="false" aria-controls="tadow-panel">
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 2.8l1.7 6.1L20 11l-6.3 2.1L12 19.2l-1.7-6.1L4 11l6.3-2.1L12 2.8Z" stroke="currentColor" stroke-width="1.5"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z" fill="currentColor"/></svg>
    </button>
    <section class="tadow-panel" id="tadow-panel" role="dialog" aria-modal="false" aria-label="TADOW AI assistant">
      <div class="tadow-header"><div class="tadow-mark" aria-hidden="true">T</div><div class="tadow-heading"><strong>TADOW AI</strong><span data-role="subtitle">DIGITAL REPRESENTATIVE</span></div><button class="tadow-close" type="button" aria-label="Close chat">×</button></div>
      <div class="tadow-messages" aria-live="polite" aria-relevant="additions"></div>
      <div class="tadow-quick" data-role="quick"></div>
      <form class="tadow-form"><textarea rows="1" maxlength="2500" aria-label="Message TADOW AI" placeholder="Ask about Ulugbek…" required></textarea><button class="tadow-send" type="submit" aria-label="Send message"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 12 20 4l-5 16-3-6-8-2Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="m12 14 4-5" stroke="currentColor" stroke-width="1.7"/></svg></button></form>
      <div class="tadow-note" data-role="note"></div>
    </section>`;
  document.body.appendChild(root);

  const launcher = root.querySelector(".tadow-launcher");
  const panel = root.querySelector(".tadow-panel");
  const closeButton = root.querySelector(".tadow-close");
  const messages = root.querySelector(".tadow-messages");
  const quick = root.querySelector('[data-role="quick"]');
  const form = root.querySelector(".tadow-form");
  const textarea = form.querySelector("textarea");
  const sendButton = form.querySelector("button");
  const history = [];
  let busy = false;
  let currentLanguage = "en";

  function language() {
    const selected = document.getElementById("language")?.value || document.documentElement.lang || "en";
    return copy[selected] ? selected : "en";
  }
  function addMessage(text, role, extraClass = "") {
    const item = document.createElement("div");
    item.className = `tadow-message ${role} ${extraClass}`.trim();
    item.textContent = text;
    messages.appendChild(item);
    messages.scrollTop = messages.scrollHeight;
    return item;
  }
  function updateLanguage() {
    currentLanguage = language();
    const t = copy[currentLanguage];
    launcher.setAttribute("aria-label", panel.classList.contains("is-open") ? t.close : t.open);
    closeButton.setAttribute("aria-label", t.close);
    root.querySelector('[data-role="subtitle"]').textContent = t.subtitle;
    textarea.placeholder = t.placeholder;
    textarea.setAttribute("aria-label", t.placeholder);
    sendButton.setAttribute("aria-label", t.send);
    root.querySelector('[data-role="note"]').textContent = t.note;
    quick.replaceChildren();
    t.quick.forEach(prompt => {
      const button = document.createElement("button");
      button.type = "button"; button.textContent = prompt;
      button.addEventListener("click", () => { textarea.value = prompt; sendMessage(); });
      quick.appendChild(button);
    });
    if (!messages.children.length) addMessage(t.welcome, "assistant");
  }
  function openPanel() {
    panel.classList.add("is-open");
    launcher.setAttribute("aria-expanded", "true");
    launcher.setAttribute("aria-label", copy[currentLanguage].close);
    textarea.focus();
  }
  function closePanel() {
    panel.classList.remove("is-open");
    launcher.setAttribute("aria-expanded", "false");
    launcher.setAttribute("aria-label", copy[currentLanguage].open);
    launcher.focus();
  }
  launcher.addEventListener("click", () => panel.classList.contains("is-open") ? closePanel() : openPanel());
  closeButton.addEventListener("click", closePanel);
  document.addEventListener("keydown", event => { if (event.key === "Escape" && panel.classList.contains("is-open")) closePanel(); });
  document.getElementById("language")?.addEventListener("change", updateLanguage);

  async function sendMessage() {
    const message = textarea.value.trim();
    if (!message || busy) return;
    busy = true; sendButton.disabled = true;
    textarea.value = ""; textarea.style.height = "42px";
    addMessage(message, "user");
    const typing = addMessage("…", "assistant", "typing");
    const priorHistory = history.slice(-10);
    try {
      const response = await fetch("/.netlify/functions/tadow-ai", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, history: priorHistory, language: currentLanguage })
      });
      const data = await response.json().catch(() => ({}));
      typing.remove();
      if (!response.ok) throw new Error(data.error || copy[currentLanguage].error);
      const answer = typeof data.answer === "string" ? data.answer : copy[currentLanguage].error;
      addMessage(answer, "assistant");
      history.push({ role: "user", content: message }, { role: "assistant", content: answer });
      if (history.length > 12) history.splice(0, history.length - 12);
    } catch (error) {
      typing.remove();
      addMessage(error.message || copy[currentLanguage].error, "assistant", "tadow-error");
    } finally {
      busy = false; sendButton.disabled = false; textarea.focus();
    }
  }
  form.addEventListener("submit", event => { event.preventDefault(); sendMessage(); });
  textarea.addEventListener("input", () => { textarea.style.height = "42px"; textarea.style.height = `${Math.min(textarea.scrollHeight, 110)}px`; });
  textarea.addEventListener("keydown", event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); sendMessage(); } });

  updateLanguage();
})();
