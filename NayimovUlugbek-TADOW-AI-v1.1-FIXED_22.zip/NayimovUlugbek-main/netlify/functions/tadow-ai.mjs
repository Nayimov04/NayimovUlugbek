import { TADOW_INSTRUCTIONS } from "../../ai/instructions.mjs";

const MAX_BODY_BYTES = 12_000;
const MAX_HISTORY_MESSAGES = 10;
const MAX_MESSAGE_CHARS = 2_500;
const MAX_OUTPUT_TOKENS = 800;
const WINDOW_MS = 10 * 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = 18;

// Best-effort per-instance throttling. Serverless instances are ephemeral;
// use a durable shared rate limiter before high-traffic production launch.
const requestLog = globalThis.__tadowRequestLog ??= new Map();

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}

function isAllowedOrigin(request) {
  const origin = request.headers.get("origin");
  if (!origin) return true;
  try {
    const originUrl = new URL(origin);
    const allowedOrigins = new Set(["https://nayimovulugbek.netlify.app"]);
    for (const value of [process.env.URL, process.env.DEPLOY_PRIME_URL]) {
      if (value) allowedOrigins.add(new URL(value).origin);
    }
    for (const value of (process.env.TADOW_ALLOWED_ORIGINS || "").split(",")) {
      const trimmed = value.trim();
      if (trimmed) allowedOrigins.add(new URL(trimmed).origin);
    }
    return allowedOrigins.has(originUrl.origin);
  } catch {
    return false;
  }
}

function isRateLimited(request) {
  const forwarded = request.headers.get("x-nf-client-connection-ip") || "unknown";
  const now = Date.now();
  const previous = (requestLog.get(forwarded) || []).filter(ts => now - ts < WINDOW_MS);
  if (previous.length >= MAX_REQUESTS_PER_WINDOW) {
    requestLog.set(forwarded, previous);
    return true;
  }
  previous.push(now);
  requestLog.set(forwarded, previous);
  if (requestLog.size > 1000) {
    for (const [key, values] of requestLog) {
      if (!values.length || now - values[values.length - 1] > WINDOW_MS) requestLog.delete(key);
    }
  }
  return false;
}

function cleanHistory(history) {
  if (!Array.isArray(history)) return [];
  return history.slice(-MAX_HISTORY_MESSAGES).flatMap(item => {
    if (!item || !["user", "assistant"].includes(item.role) || typeof item.content !== "string") return [];
    const content = item.content.trim().slice(0, MAX_MESSAGE_CHARS);
    return content ? [{ role: item.role, content }] : [];
  });
}

export default async (request) => {
  if (request.method !== "POST") return json({ error: "Method not allowed." }, 405);
  if (!isAllowedOrigin(request)) return json({ error: "Origin not allowed." }, 403);
  if (isRateLimited(request)) return json({ error: "Too many messages. Please wait a few minutes and try again." }, 429);

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return json({ error: "TADOW AI is not configured yet. Please try again later." }, 503);

  const contentLength = Number(request.headers.get("content-length") || 0);
  if (contentLength > MAX_BODY_BYTES) return json({ error: "Your message is too large." }, 413);

  let body;
  try {
    const rawBody = await request.text();
    if (new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) {
      return json({ error: "Your message is too large." }, 413);
    }
    body = JSON.parse(rawBody);
  } catch {
    return json({ error: "Invalid request format." }, 400);
  }

  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return json({ error: "The request body must be a JSON object." }, 400);
  }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  if (!message) return json({ error: "Please enter a message." }, 400);
  if (message.length > MAX_MESSAGE_CHARS) return json({ error: `Please keep messages under ${MAX_MESSAGE_CHARS} characters.` }, 400);

  const supportedLanguages = new Set(["en", "ko", "uz", "ru", "es", "de"]);
  const language = supportedLanguages.has(body.language) ? body.language : "en";
  const history = cleanHistory(body.history);
  const input = [...history, { role: "user", content: message }];
  const model = process.env.OPENAI_MODEL || "gpt-6-astra";
  const enableWebSearch = process.env.TADOW_ENABLE_WEB_SEARCH === "true";

  const payload = {
    model,
    instructions: `${TADOW_INSTRUCTIONS}\n\nThe visitor's currently selected website language is: ${language}. Reply in that language.`,
    input,
    max_output_tokens: MAX_OUTPUT_TOKENS,
    store: false,
  };
  if (enableWebSearch) payload.tools = [{ type: "web_search", search_context_size: "low" }];

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 45_000);
  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("TADOW AI provider error:", response.status, result?.error?.type || "unknown");
      if (response.status === 429) return json({ error: "TADOW AI is receiving too many requests. Please try again shortly." }, 503);
      if (response.status === 401 || response.status === 403) return json({ error: "TADOW AI configuration needs attention. Please contact the website owner." }, 503);
      return json({ error: "TADOW AI could not complete that request. Please try again." }, 502);
    }

    const answer = (result.output || [])
      .filter(item => item.type === "message")
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text || "")
      .join("\n")
      .trim();

    if (!answer) return json({ error: "I couldn't prepare an answer just now. Please try again." }, 502);
    return json({ answer });
  } catch (error) {
    console.error("TADOW AI request failed:", error?.name || "Error");
    return json({ error: error?.name === "AbortError" ? "That took too long. Please try again." : "Connection problem. Please try again shortly." }, 502);
  } finally {
    clearTimeout(timeout);
  }
};
