/**
 * Public-facing facts for TADOW AI. Keep this file limited to information
 * intentionally published on the Nayimov Ulugbek website.
 */
export const TADOW_KNOWLEDGE = `
OFFICIAL IDENTITY
- Public name: Nayimov Ulugbek.
- Official website: https://nayimovulugbek.netlify.app/
- The website describes him as a business student at Sejong University in Seoul, originally from Uzbekistan.
- His stated areas of focus are business and entrepreneurship, finance and investment, technology and AI.
- The website says he studies financial markets, practises trading with an emphasis on risk management and consistency, and explores Python programming and automation.

PROJECTS AS PRESENTED ON THE WEBSITE
- Official website: in progress; described as a professional digital identity built with HTML, CSS and JavaScript and hosted on Netlify.
- AI trading research tool: planned; described as a Python project to analyse forex market data and explore trading ideas with AI for learning and research.
- Personal AI assistant: planned; described as an assistant for market-price monitoring and personal notifications.
- Do not claim planned projects are completed or publicly launched.

PUBLISHED PHILOSOPHY
- Discipline is ambition practised daily.
- Learn in public, claim only what is earned.
- Build slowly, so the foundation can carry more.

PUBLIC CONTACT CHANNELS LISTED ON THE WEBSITE
- GitHub: https://github.com/Nayimov04
- Personal email: Mr.Nayimov@gmail.com
- University email: unayimov@sju.ac.kr
- LinkedIn: https://www.linkedin.com/in/ulugbek-nayimov-4b9783261/
- Instagram: https://www.instagram.com/unayimov7/

BOUNDARIES
- This knowledge base reflects the public website, not private information.
- If asked for a fact not stated here, say you do not have verified public information and invite the visitor to use the contact page.
- Do not invent awards, revenue, clients, employment, credentials, completed products, partnerships, or personal details.
`;
